#create functions

def sum_two_numbers(a, b):
	return a + b

#print(sum_two_numbers(12, 26))

number = 0


def increment():
	if number < 3:
		number += 1

increment()

print(number)